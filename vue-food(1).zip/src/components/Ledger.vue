<template>
    <div>
        <div class="h-30 bg-light-50 flex justify-end items-center">
            <div class="flex justify-center items-center mr-20">
                <img src="../assets/img/sp/tit3.png" alt="">
            </div>
        </div>

        
        <div class="bg-turntable w-full h-200 justify-center items-center felx coulmn relative">
           

    </div>
</div>

</template>

<script>
import * as echarts from 'echarts';
export default {
    data() {
        return {
            activeIndex: 0
        }
    },
    methods: {
        

       
    },

    mounted() {

    },

    created() {

    }
}
</script>

<style lang="less" scoped>
.bg-turntable {
    background: #f7e3c2;
}

/deep/.el-container .el-main {
    background-color: #fff !important;
}

body {
    background-color: #fff !important;
}
.borderLine{
    border: 1px solid #918d86;
}
.bgInput1{
    background: #e6c4ab;
}
.bgInput2{
    background: #f7e3c2;
}
</style>
