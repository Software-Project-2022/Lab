module.exports = {
    pluginOptions: {
      windicss: {
        // 具体配置请查看 https://github.com/windicss/vite-plugin-windicss/blob/main/packages/plugin-utils/src/options.ts
      },
    },
  }