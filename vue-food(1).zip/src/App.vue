<template>
  <div id="app">
		<!-- 路由占位符 -->
		<router-view></router-view>
  </div>
</template>

<script>
export default {
  name: 'app',
  components: {

  }
}
</script>

<style>
*{
	padding: 0;
	margin: 0;
}
</style>
